#!/bin/bash

rm -rf *.vs
rm -rf Saved
rm -rf Binaries
rm -rf Build
rm -rf Intermediate
rm -rf DerivedDataCache
rm -rf Script

rm -rf Plugins\JSBSimFlightDynamicsModel\Binaries
rm -rf Plugins\JSBSimFlightDynamicsModel\Intermediate