.. JSBSim documentation master file, created by
   sphinx-quickstart on Sat Aug 17 20:12:20 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

============================
JSBSim Flight Dynamics Model
============================

.. toctree::
   :maxdepth: 2
   :hidden:
   :glob:

   *

.. include:: mainpage.rst
